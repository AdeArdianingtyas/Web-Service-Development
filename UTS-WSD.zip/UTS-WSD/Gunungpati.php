<?php
	$json_string = file_get_contents("http://api.wunderground.com/api/46166be0792b6d51/conditions/q/IA/gunungpati.json");
	$parsed_json = json_decode($json_string);
	$conditions = $parsed_json->{'current_observation'}->{'display_location'}->{'city'};
	$conditions2 = $parsed_json->{'current_observation'}->{'display_location'}->{'state_name'};
	
	$json_string2 = file_get_contents("http://api.wunderground.com/api/46166be0792b6d51/yesterday/q/IA/gunungpati.json");
	$parsed_json2 = json_decode($json_string2);
	$yesterday = $parsed_json2->{'history'}->{'date'}->{'pretty'};
	
	$json_string3 = file_get_contents("http://api.wunderground.com/api/46166be0792b6d51/planner_03010331/q/IA/gunungpati.json");
	$parsed_json3 = json_decode($json_string3);
	$planner = $parsed_json3->{'trip'}->{'cloud_cover'}->{'cond'};
	$planner2 = $parsed_json3->{'trip'}->{'chance_of'}->{'chanceofwindyday'}->{'description'};
	$planner3 = $parsed_json3->{'trip'}->{'chance_of'}->{'chanceofhumidday'}->{'description'};
	
	$json_string4 = file_get_contents("http://api.wunderground.com/api/46166be0792b6d51/satellite/q/IA/gunungpati.json");
	$parsed_json4 = json_decode($json_string4);
	$satellite = $parsed_json4->{'satellite'}->{'image_url'};
	
	echo "Nama kota nya adalah : ${conditions}\n";
	echo "<br>";
	echo "Nama negara nya adalah : ${conditions2}\n";
	echo "<br>";
	echo "Tanggal saat ini adalah : ${yesterday}\n";
	echo "<br>";
	echo "Kondisi awan nya adalah : ${planner}\n";
	echo "<br>";
	echo "Kecepatan angin nya adalah : ${planner2}\n";
	echo "<br>";
	echo "Tingkat kelembaban udara nya adalah : ${planner3}\n";
	echo "<br>";
	echo "Satelite : <br>
	<img src = '$satellite'>\n";
?>